<?php

namespace App\Http\Controllers;

use App\Model\AssessmentModel;
use App\Services\BusinessService;
use Illuminate\Http\Request;

class AssessmentController {
    
    private $businessService;
    
    public function index(Request $request) {
        // get posted data and store into variables
        $postedField1 = request()->get('field1');
        $postedField2 = request()->get('field2');
        $postedField3 = request()->get('field3');
        $postedField4 = request()->get('field4');
        
        // create an AssessmentModel object using the stored variables
        $newAssessmentModel = new AssessmentModel($postedField1, $postedField2, $postedField3, $postedField4);
        
        // instantiate a BusinessService object
        $this->businessService = new BusinessService();
        
        // use the BusinessService function to return a boolean value for if any properties of AssessmentModel equal "CST-236"
        $foundString = $this->businessService->compare($newAssessmentModel);
        
        // use the returned boolean value from the BusinessService compare function to return to the assessment view with the boolean value
        if ($foundString) {
            return view('assessment')->with('foundStringBool', $foundString)
                                     ->with('assessmentModel', $newAssessmentModel);
        }
        else {
            return view('assessment')->with('foundStringBool', $foundString)
                                     ->with('assessmentModel', $newAssessmentModel);
        }
    }
}