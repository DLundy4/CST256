<?php
namespace App\Services;

use App\Model\AssessmentModel;

class BusinessService {
    
    // function receives an AssessmentModel parameter and checks each property for if the value equals "CST-236" in which 
    // case the function would stop and return true.
    // If a property does not equal "CST-236", the next property gets checked for same condition until the final property
    // is checked which will return fasle if the final property is not equal to "CST-236".
    public function compare(AssessmentModel $assessmentModel) {
        if ($assessmentModel->getProperty1() == "CST-236") {
            return true;
        }
        else {
            if ($assessmentModel->getProperty2() == "CST-236") {
                return true;
            }
            else {
                if ($assessmentModel->getProperty3() == "CST-236") {
                    return true;
                }
                else {
                    if ($assessmentModel->getProperty4() == "CST-236") {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
            }
        }
    }
    
}