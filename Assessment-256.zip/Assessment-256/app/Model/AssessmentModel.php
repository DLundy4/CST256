<?php
namespace App\Model;

class AssessmentModel {
    
    // AssessmentModel private properties
    private $property1;
    private $property2;
    private $property3;
    private $property4;
    
    // Constructor method for the Assessment Model to set supplied parameters to private properties
    public function __construct($property1, $property2, $property3, $property4){
        $this->property1 = $property1;
        $this->property2 = $property2;
        $this->property3 = $property3;
        $this->property4 = $property4;
    }
    
    
    // Auto-generated getter and setter methods for the AssessmentModel properties
    /**
     * @return mixed
     */
    public function getProperty1()
    {
        return $this->property1;
    }

    /**
     * @return mixed
     */
    public function getProperty2()
    {
        return $this->property2;
    }

    /**
     * @return mixed
     */
    public function getProperty3()
    {
        return $this->property3;
    }

    /**
     * @return mixed
     */
    public function getProperty4()
    {
        return $this->property4;
    }

    /**
     * @param mixed $property1
     */
    public function setProperty1($property1)
    {
        $this->property1 = $property1;
    }

    /**
     * @param mixed $property2
     */
    public function setProperty2($property2)
    {
        $this->property2 = $property2;
    }

    /**
     * @param mixed $property3
     */
    public function setProperty3($property3)
    {
        $this->property3 = $property3;
    }

    /**
     * @param mixed $property4
     */
    public function setProperty4($property4)
    {
        $this->property4 = $property4;
    }

}