<?php 
use App\Services\BusinessService;
use App\Model\AssessmentModel;
?>

<html>
<head>
<title>Assessment</title>
</head>
<body>
<div align="center">
	<h1>Input Form</h1>
	@if (isset($foundStringBool))
    	@if ($foundStringBool == true)
        	<h2>String "CST-236" found!</h2>
        	<p>Property1 = {{$assessmentModel->getProperty1()}}</p>
        	<p>Property2 = {{$assessmentModel->getProperty2()}}</p>
        	<p>Property3 = {{$assessmentModel->getProperty3()}}</p>
        	<p>Property4 = {{$assessmentModel->getProperty4()}}</p>
    	
    	@else
        	<h2>String "CST-236" not found</h2>
        	<p>Property1 = {{$assessmentModel->getProperty1()}}</p>
        	<p>Property2 = {{$assessmentModel->getProperty2()}}</p>
        	<p>Property3 = {{$assessmentModel->getProperty3()}}</p>
        	<p>Property4 = {{$assessmentModel->getProperty4()}}</p>
    	@endif
    @endif
    <form action="addAssessmentObj" method="post">
    	{{ csrf_field() }}
    	<label for="field1">Field1</label><br>
    	<input type="text" name="field1" id="field1"><br>
    	<label for="field2">Field2</label><br>
    	<input type="text" name="field2" id="field2"><br>
    	<label for="field3">Field3</label><br>
    	<input type="text" name="field3" id="field3"><br>
    	<label for="field4">Field4</label><br>
    	<input type="text" name="field4" id="field4">
    	<br><br>
    	<input type="submit" value="Submit">
    </form>
</div>
</body>
</html>