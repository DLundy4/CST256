<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Services\Business\SecurityService;

class OrderController extends Controller
{
    public function index(Request $request){
        
        $customerData = new CustomerModel($request->input('firstName'), $request->input('lastName'));
        
        
        $product = request()->get('product');
        
        $customerID = $request->input('customerID');
        
        $serviceCustomer = new SecurityService();
        
        $isValid = $serviceCustomer->addAllInformation($product, $customerID, $customerData);
        
        if ($isValid) {
            echo "Order Data Committed Successfully";
        }
        else {
            echo "Order Data Was Rolled Back";
        }
        return view('order');
    }
    
    private function validateForm(Request $request) {
        $rules = ['user_name' => 'Required | Between: 4, 10 | Alpha', 'password' => 'Required | Between: 4, 10'];
        $this->validate($request, $rules);
    }
}