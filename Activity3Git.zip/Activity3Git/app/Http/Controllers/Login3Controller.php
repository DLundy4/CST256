<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\Business\SecurityService;

class Login3Controller extends Controller
{
    public function index(Request $request){
        $this->validateForm($request);
        
        $credentials = new UserModel(request()->get('user_name'), request()->get('password'));
        
        $serviceLogin = new SecurityService();
        
        $isValid = $serviceLogin->login($credentials);
        
        if ($isValid) {
            return view('loginPassed2');
        }
        else {
            return view('loginFailed');
        }
        
//         $formValues = $request->all();
        
//         $userName = request()->get('user_name');
        
// //         $userName = request()->input('user_name');
        
//         return $request->all();
    }
    
    private function validateForm(Request $request) {
        $rules = ['user_name' => 'Required | Between: 4, 10 | Alpha', 'password' => 'Required | Between: 4, 10'];
        $this->validate($request, $rules);
    }
}