<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Services\Business\SecurityService;

class CustomerController extends Controller
{
    public function index(Request $request){
        
//         $customerData = new CustomerModel(request()->get('firstname'), request()->get('lastname'));
        
//         $serviceCustomer = new SecurityService();
        
//         $isValid = $serviceCustomer->addCustomer($customerData);
        
//         if ($isValid) {
//             echo "Customer Data Added Successfully";
//         }
//         else {
//             echo "Customer Data Was Not Added";
//         }
        $nextID = 0;
        return redirect('neworder')->with('nextID', $nextID)
                                   ->with('firstName', request()->get('firstname'))
                                   ->with('lastName', request()->get('lastname'));
        
//         $formValues = $request->all();
        
//         $userName = request()->get('user_name');
        
// //         $userName = request()->input('user_name');
        
//         return $request->all();
    }
    
    private function validateForm(Request $request) {
        $rules = ['user_name' => 'Required | Between: 4, 10 | Alpha', 'password' => 'Required | Between: 4, 10'];
        $this->validate($request, $rules);
    }
}