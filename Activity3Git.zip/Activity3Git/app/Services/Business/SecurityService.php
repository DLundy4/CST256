<?php
namespace App\Services\Business;

use App\Models\UserModel;
use App\Models\CustomerModel;
use App\Services\Data\SecurityDAO;
use App\Services\Data\CustomerDAO;
use App\Services\Data\OrderDAO;
use App\Services\Data\Utility\DBConnect;

class SecurityService {
    private $verifyCred;
    private $addNewCustomer;
    private $addNewOrder;
    
    public function login(UserModel $credentials) {
        $this->verifyCred = new SecurityDAO();
        
        return $this->verifyCred->findByUser($credentials);
    }
    
    public function addCustomer($customer) {
        $this->addNewCustomer = new CustomerDAO();
        return $this->addNewCustomer->addCustomer($customer);
    }
    
    public function addOrder(string $product, int $customerID) {
        $this->addNewOrder = new OrderDAO();
        return $this->addNewOrder->addOrder($product, $customerID);
    }
    
    public function addAllInformation(string $product, int $CustomerID, CustomerModel $CustomerData){
        $conn = new DBConnect("activity3");
        $dbObj = $conn->getDBConnect();
        $conn->setDBAutoCommitFalse();
        $conn->beginTransaction();
        $this->addNewCustomer = new CustomerDAO($dbObj);
        $customerID = $this->addNewCustomer->getNextID();
        $isSuccessful = $this->addNewCustomer->addCustomer($CustomerData);
        $this->addNewOrder = new OrderDAO($dbObj);
        $isSuccessfulOrder = $this->addNewOrder->addOrder($product, $customerID);
        if ($isSuccessful && $isSuccessfulOrder) {
            $conn->commitTransaction();
            return true;
        }
        else {
            $conn->rollBackTransaction();
            return false;
        }
    }
}