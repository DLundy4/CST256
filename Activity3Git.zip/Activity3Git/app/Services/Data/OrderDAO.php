<?php
namespace App\Services\Data;

use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;

class OrderDAO {
    
    private $connObject;
    private $dbname = "activity3";
    private $dbQuery;
    private $connection;
    private $dbObj;
    
    
    public function __construct($dbObj)
    {
        $this->dbObj = $dbObj;
    }
    
    public function addOrder(string $product, int $customerID) {
        try {
            $this->dbQuery = @"INSERT INTO `order`
                              (Product, CustomerID)
                              VALUES
                              ('" . $product . "', " . $customerID . ")";
            
//             $result = mysqli_query($this->conn, $this->dbQuery);

            if($this->dbObj->query($this->dbQuery)) {
//                 $this->connObject->closeDBConnect();
                return true;
            } else {
//                 $this->connObject->closeDBConnect();
                return false;
            }
        } catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    
}