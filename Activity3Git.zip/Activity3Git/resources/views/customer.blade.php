@extends('layouts.appmaster')
@section('title', 'Customer')
@section('content')

<form action="addCustomer" method="post">
{{ csrf_field() }}
<div class="demo-table">
	<div class="form-head">Customer</div>
	<div class="field-column">
		<label for="firstname">First Name</label><span id="user_info" class="error-info"></span>
	</div>
	<div>
		<input name="firstname" id="firstname" type="text" class="demo-input-box">
	</div>
	
	<div class="field-column">
		<label for="lastname">Last Name</label><span id="lastname" class="error-info"></span>
	</div>
	<div>
		<input name="lastname" id="lastname" type="text" class="demo-input-box">
	</div>
	
	<div class="field-column">
		<input type="submit" class="btnLogin">
	</div>
</div>
</form>

@endsection
